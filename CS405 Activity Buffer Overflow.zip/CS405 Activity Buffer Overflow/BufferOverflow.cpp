// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_order
	//  variable, and its position in the declaration. It must always be directly before the variable used for input.

	const std::string account_number = "CharlieBrown42";
	char user_input[20];

	const int MAX_INPUT_SIZE = 20;	// We want to know exactly how large our character array can handle. This should be used in the declaration of the array as well, but that is being left unchanged
	std::string full_input;			// We'll put the input into a string first, since it can handle an input of theoretically any size, limited only by system memory

	// Request a value and receive the input from the user
	std::cout << "Enter a value: ";
	std::cin >> full_input;

	// Check the size of the string entered with the size that we can handle
	// The last character of the array has to be a null character, so we only allow strings one less than the MAX_INPUT_SIZE
	if (full_input.size() <= MAX_INPUT_SIZE - 1) {
		// Copy the input into the character array now that we've confirmed that it's of an appropriate size
		// We're using strncpy_s since it ensures a null-terminated string. If it were a strict requirement that we allow exactly 20
		// characters for the array then we could potentially use strncpy to avoid the addition of the null terminator or we could copy the characters
		// individually to the array, but this would leave us with a potentially vulnerable non-null terminated string in the array
		// We could also increase the size of the array by 1 to allow for room for the null terminator, but we've been specifically asked
		// not to change the array declaration
		strncpy_s(user_input, full_input.c_str(), sizeof(user_input));

		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}
	else {
		// The input was too large, so report an error and return an error value to the calling code
		std::cout << "The value that you entered was too long." << std::endl;
		return -1;
	}

	return 0;
}
