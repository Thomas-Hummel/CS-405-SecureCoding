#include "CustomException.h"

CustomException::CustomException() :
	exceptionMessage("My Custom Exception") {}

// Override of the base standard exception what method
// We'll only return the value. Calling code will be responsible for displaying it
// since trying to display it here could cause unintended consequences and is out of scope
const char* CustomException::what() const throw() {
	return exceptionMessage.c_str();
}
