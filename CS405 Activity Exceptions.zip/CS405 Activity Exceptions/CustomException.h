#include <exception>
#include <string>
#include <iostream>

#pragma once

// A custom exception class for raising a custom exception
class CustomException : public std::exception
{
private:
	std::string exceptionMessage;
public:
	CustomException();
	const char* what() const throw();
};
